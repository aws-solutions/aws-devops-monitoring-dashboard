#!/bin/bash
export SOLUTION_ID='SO0143'
export SOLUTION_NAME='AWS DevOps Monitoring Dashboard'
export SOLUTION_TRADEMARKEDNAME='aws-devops-monitoring-dashboard'