/*********************************************************************************************************************
 *  Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.                                                *
 *                                                                                                                    *
 *  Licensed under the Apache License Version 2.0 (the 'License'). You may not use this file except in compliance     *
 *  with the License. A copy of the License is located at                                                             *
 *                                                                                                                    *
 *      http://www.apache.org/licenses/LICENSE-2.0                                                                    *
 *                                                                                                                    *
 *  or in the 'license' file accompanying this file. This file is distributed on an 'AS IS' BASIS, WITHOUT WARRANTIES *
 *  OR CONDITIONS OF ANY KIND, express or implied. See the License for the specific language governing permissions    *
 *  and limitations under the License.                                                                                *
 *********************************************************************************************************************/


'use strict';

const LOGGER = new (require('./lib/logger'))();

/**
 * Transform AWS CloudWatch events from AWS Synthetic Canary Alarm
 */

let TransformSyntheticCanaryAlarmEvents = (data, recordNumber) => {

    LOGGER.log('INFO', 'Start transforming Synthetic Canary Alarm CW Event ' + recordNumber.toString());

    let detailData = {};
    let transformedRecord = {};
    let transformedDetail = {};

    // If it is NOT the alarm for calculating MTTR used by the solution, stop processing but return empty record
    const resources = data.hasOwnProperty('resources') ? data['resources'].toString() : '';
    if (resources.indexOf(process.env.SOLUTION_ID) == -1 && resources.indexOf('-MTTR') == -1) {
        return transformedRecord;
    }

    //Process event data
    for (var key in data) {
        //Keep key values that are not under detail tag (common in all cloudwatch events)
        if (key !== 'detail') {
            if (key !== 'detail-type')
                transformedRecord[key] = !transformedRecord.hasOwnProperty(key) ? data[key] : null;
            //rename key detail-type to detail_type to support athena query
            else transformedRecord['detail_type'] = !transformedRecord.hasOwnProperty(key) ? data[key] : null;
        }
        //process key values under detail tag that are specific only to current event
        else {
            detailData = data["detail"];

            // extract current state data from alarm name
            const currentState = detailData['state'];
            transformedDetail['alarmCurrState'] = currentState['value'];
            transformedDetail['alarmCurrStateTimeStamp']  //convert to Athena's timestamp format: yyyy-mm-ddThh:mm:ssZ
                = currentState.hasOwnProperty("timestamp") ? new Date(currentState['timestamp']).toISOString().substring(0, 19) + 'Z' : '';

            // extract previous state data from alarm name
            const previousState = detailData['previousState'];
            transformedDetail['alarmPrevState'] = previousState['value'];
            transformedDetail['alarmPrevStateTimeStamp'] //convert to Athena's timestamp format: yyyy-mm-ddThh:mm:ssZ
                = previousState.hasOwnProperty("timestamp") ? new Date(previousState['timestamp']).toISOString().substring(0, 19) + 'Z' : '';

            // get MTTR canary alarm name: SolutionId-[AppName]-[RepoName]-MTTR
            const alarmName = detailData["alarmName"];
            transformedDetail['alarmName'] = alarmName;

            // extract application name from alarm name
            let startIndex = alarmName.indexOf('[');
            let endIndex = alarmName.indexOf(']');
            transformedDetail['alarmAppName'] = (startIndex !== -1 && endIndex !== -1) ? alarmName.substring(startIndex + 1, endIndex) : '';

            // extract repository name from alarm name
            startIndex = alarmName.lastIndexOf('[');
            endIndex = alarmName.lastIndexOf(']');
            transformedDetail['alarmRepoName'] = (startIndex !== -1 && endIndex !== -1) ? alarmName.substring(startIndex + 1, endIndex) : '';

            // extract namespace as alarm type
            const alarmType = detailData['configuration']['metrics'][0]['metricStat']['metric']['namespace'];
            transformedDetail['alarmType'] = alarmType === 'CloudWatchSynthetics' ? 'Canary' : 'CodePipeline';

            // calculate recovery duration minutes
            let durationMinutes = -1;
            if (transformedDetail['alarmCurrStateTimeStamp'].length > 0 && transformedDetail['alarmPrevStateTimeStamp'].length > 0) {
                const startTime = new Date(transformedDetail['alarmPrevStateTimeStamp']);
                const endTime = new Date(transformedDetail['alarmCurrStateTimeStamp']);
                const difference = endTime.getTime() - startTime.getTime(); // This will give difference in milliseconds
                durationMinutes = Math.round(difference / 60000);
            }
            transformedDetail['recoveryDurationMinutes'] = durationMinutes;
        }//end else
    }//end for loop

    transformedRecord['detail'] = transformedDetail;

    LOGGER.log('DEBUG', 'Transformed record: ' + JSON.stringify(transformedRecord, null, 2));
    LOGGER.log('INFO', 'End transforming Synthetic Canary Alarm CW Event ' + recordNumber.toString());

    return transformedRecord;

};

module.exports = {
    transformSyntheticCanaryAlarmEvents: TransformSyntheticCanaryAlarmEvents
};