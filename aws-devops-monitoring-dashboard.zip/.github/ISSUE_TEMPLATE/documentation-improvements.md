---
name: Documentation improvements
about: Suggest a documentation update
title: ''
labels: documentation
assignees: ''

---

**What were you initially searching for in the docs?**
<!--- Please help us understand how you looked for information that was either not available or unclear -->

**Is this related to an existing part of the documentation? Please share a link**

**Describe how we could make it clearer**

**If you have a proposed update, please share it here**